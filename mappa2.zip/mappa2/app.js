import express from 'express';
import * as db from './data/db.js';

const PORT = 3000;
const app = express();

app.use(express.json());

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

app.get('/comments', (req, res) => {
    const comments = db.getAllComments();
    res.status(200).json(comments);
});

app.get('/comments/:id', (req, res) => {
    const id = req.params.id;
    const comment = db.getCommentsById(id);
    if (comment) {
        res.status(200).json(comment);
    } else {
        res.status(404).json({ error: 'Comment not found' });
    }
});

app.post('/comments', (req, res) => {
    const { author, message } = req.body;
    if (!author || !message) {
        return res.status(400).json({ error: 'Author and message are required' });
    }
    const newCom = db.saveComment(author, message);
    const comment = db.getCommentsById(newCom.lastInsertRowid);
    res.status(201).json(comment);
});

app.put('/comments/:id', (req, res) => {
    const id = req.params.id;
    const comment = db.getCommentsById(id);
    const { author, message } = req.body;
    if (!author || !message) {
        return res.status(400).json({ error: 'Author and message are required' });
    }
    if (!comment) {
        res.status(400).json({ error: 'Comment not found' });
    }
    db.updateComments(author, message, id);
    res.status(200).json({message: "Update successful"});
});

app.delete('/comments/:id', (req, res) => {
    const id = req.params.id;
    const comment = db.getCommentsById(id);
    if (!comment) {
        res.status(404).json({ error: 'Comment not found' });
    }
    db.deleteComments(id);
    res.status(204).json({message: "Delete successful"});
});