import Database from "better-sqlite3";
const db = new Database("./data/database.sqlite");

db.prepare(
        `CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT, message TEXT)
    `).run();

export function getAllComments(){
    return db.prepare(`SELECT * FROM comments`).all();
}

export function getCommentsById(id){
    return db.prepare(`SELECT * FROM comments WHERE id = ?`).get(id);
}

export function saveComment(author, message){
    return db.prepare(`INSERT INTO comments (author, message) VALUES (?, ?)`).run(author, message);
}

export function updateComments(author, message, id){
    return db.prepare(`UPDATE comments set author = ?, message = ? WHERE id = ?`).run(author, message, id);
}

export function deleteComments(id){
    return db.prepare(`DELETE FROM comments where id = ?`).run(id);
}