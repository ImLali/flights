import express from "express";
import db from "./data/db.js";

const app = express();
app.use(express.json());

app.get("/companies", (req, res) => {
    const companies = db.getAllCompanies();
    res.json(companies);
});

app.get("/companies/:id", (req, res) => {
    const company = db.getCompanyById(req.params.id);
    if (company) {
        res.json(company);
    } else {
        res.status(404).json({ error: "Company not found" });
    }
});

app.post("/companies", (req, res) => {
    const newCompany = db.createCompany(req.body);
    res.status(201).json(newCompany);
});

app.put("/companies/:id", (req, res) => {
    const updatedCompany = db.updateCompany(req.params.id, req.body);
    if (updatedCompany) {
        res.json(updatedCompany);
    } else {
        res.status(404).json({ error: "Company not found" });
    }
});

app.delete("/companies/:id", (req, res) => {
    db.deleteCompany(req.params.id);
    res.status(204).end();
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});