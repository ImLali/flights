import Database from "better-sqlite3";

const db = new Database("./data/database.sqlite");

db.prepare(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    city STRING NOT NULL,
    zipcode INT NOT NULL,
    company STRING NOT NULL,
    address STRING NOT NULL
`).run();

export function getAllCompanies() {
    const stmt = db.prepare("SELECT * FROM users");
    return stmt.all();
}

export function getCompanyById(id) {
    const stmt = db.prepare("SELECT * FROM users WHERE id = ?");
    return stmt.get(id);
}

export function createCompany(company) {
    const stmt = db.prepare("INSERT INTO users (city, zipcode, company, address) VALUES (?, ?, ?, ?)");
    const info = stmt.run(company.city, company.zipcode, company.company, company.address);
    return getCompanyById(info.lastInsertRowid);
}

export function updateCompany(id, company) {
    const stmt = db.prepare("UPDATE users SET city = ?, zipcode = ?, company = ?, address = ? WHERE id = ?");
    stmt.run(company.city, company.zipcode, company.company, company.address, id);
    return getCompanyById(id);
}

export function deleteCompany(id) {
    const stmt = db.prepare("DELETE FROM users WHERE id = ?");
    stmt.run(id);
}

export default {
    getAllCompanies,
    getCompanyById,
    createCompany,
    updateCompany,
    deleteCompany
};
