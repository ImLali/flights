import express from 'express';
import * as db from './data/db.js';
import path from 'path';
import { fileURLToPath } from 'url';

const PORT = 3000;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json());
app.use(express.static(__dirname));

app.get('/api/airports', (req, res) => {
    const airports = db.getAllAirports();
    res.status(200).json(airports);
});

app.get('/api/flights/:startAirportId', (req, res) => {
    const startAirportId = req.params.startAirportId;
    const flights = db.getFlightsByDeparture(startAirportId);
    res.status(200).json(flights);
});

app.get('/api/flight/:id', (req, res) => {
    const id = req.params.id;
    const flight = db.getFlightById(id);
    if (flight) {
        res.status(200).json(flight);
    } else {
        res.status(404).json({ error: 'Flight not found' });
    }
});

app.post('/api/flights', (req, res) => {
    console.log('POST /api/flights - Body:', req.body);
    const { startAirportId, endAirportId, startTime, endTime, price, duration } = req.body;
    
    console.log('Extracted:', { startAirportId, endAirportId, startTime, endTime, price, duration });
    
    if (!startAirportId || !endAirportId || !startTime || !endTime || !price || !duration) {
        console.log('Validation failed!');
        return res.status(400).json({ error: 'All fields are required' });
    }
    
    try {
        const result = db.createFlight(startAirportId, endAirportId, startTime, endTime, price, duration);
        console.log('Flight created, lastInsertRowid:', result.lastInsertRowid);
        const flight = db.getFlightById(result.lastInsertRowid);
        res.status(201).json(flight);
    } catch (error) {
        console.error('Error creating flight:', error);
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/flights/:id', (req, res) => {
    const id = req.params.id;
    const flight = db.getFlightById(id);
    
    if (!flight) {
        return res.status(404).json({ error: 'Flight not found' });
    }
    
    const { startAirportId, endAirportId, startTime, endTime, price, duration } = req.body;
    
    if (!startAirportId || !endAirportId || !startTime || !endTime || !price || !duration) {
        return res.status(400).json({ error: 'All fields are required' });
    }
    
    db.updateFlight(id, startAirportId, endAirportId, startTime, endTime, price, duration);
    const updatedFlight = db.getFlightById(id);
    res.status(200).json(updatedFlight);
});

app.delete('/api/flights/:id', (req, res) => {
    const id = req.params.id;
    const flight = db.getFlightById(id);
    
    if (!flight) {
        return res.status(404).json({ error: 'Flight not found' });
    }
    
    db.deleteFlight(id);
    res.status(204).send();
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});