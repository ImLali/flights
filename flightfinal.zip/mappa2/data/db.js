import Database from "better-sqlite3";
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new Database(dbPath);

// Airports tábla
db.prepare(`CREATE TABLE IF NOT EXISTS airports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT,
    city TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS flights (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    departure_airport_id INTEGER,
    arrival_airport_id INTEGER,
    departure_time TEXT,
    arrival_time TEXT,
    cost REAL,
    duration TEXT,
    FOREIGN KEY(departure_airport_id) REFERENCES airports(id),
    FOREIGN KEY(arrival_airport_id) REFERENCES airports(id)
)`).run();

const existingAirports = db.prepare(`SELECT COUNT(*) as count FROM airports`).get();
if (existingAirports.count === 0) {
    db.prepare(`INSERT INTO airports (code, name, city) VALUES (?, ?, ?)`).run('BUD', 'Budapest Ferenc Liszt', 'Budapest');
    db.prepare(`INSERT INTO airports (code, name, city) VALUES (?, ?, ?)`).run('VIE', 'Vienna International', 'Vienna');
    db.prepare(`INSERT INTO airports (code, name, city) VALUES (?, ?, ?)`).run('PRG', 'Prague Václav Havel', 'Prague');
    db.prepare(`INSERT INTO airports (code, name, city) VALUES (?, ?, ?)`).run('WAW', 'Warsaw Chopin', 'Warsaw');
}

export function getAllAirports(){
    return db.prepare(`SELECT * FROM airports`).all();
}

export function getFlightsByDeparture(startAirportId){
    return db.prepare(`
        SELECT 
            f.id,
            f.departure_time as startTime,
            f.arrival_time as endTime,
            f.cost as price,
            f.duration,
            a1.code as departure_code,
            a1.name as departure_name,
            a2.code as arrival_code,
            a2.name as arrival_name
        FROM flights f
        JOIN airports a1 ON f.departure_airport_id = a1.id
        JOIN airports a2 ON f.arrival_airport_id = a2.id
        WHERE f.departure_airport_id = ?
    `).all(startAirportId);
}

export function getFlightById(id){
    return db.prepare(`
        SELECT 
            f.id,
            f.departure_airport_id,
            f.arrival_airport_id,
            f.departure_time as startTime,
            f.arrival_time as endTime,
            f.cost as price,
            f.duration,
            a1.code as departure_code,
            a1.name as departure_name,
            a2.code as arrival_code,
            a2.name as arrival_name
        FROM flights f
        JOIN airports a1 ON f.departure_airport_id = a1.id
        JOIN airports a2 ON f.arrival_airport_id = a2.id
        WHERE f.id = ?
    `).get(id);
}

export function createFlight(startAirportId, endAirportId, startTime, endTime, price, duration){
    return db.prepare(`
        INSERT INTO flights (departure_airport_id, arrival_airport_id, departure_time, arrival_time, cost, duration)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(startAirportId, endAirportId, startTime, endTime, price, duration);
}

export function updateFlight(id, startAirportId, endAirportId, startTime, endTime, price, duration){
    return db.prepare(`
        UPDATE flights 
        SET departure_airport_id = ?, arrival_airport_id = ?, departure_time = ?, arrival_time = ?, cost = ?, duration = ?
        WHERE id = ?
    `).run(startAirportId, endAirportId, startTime, endTime, price, duration, id);
}

export function deleteFlight(id){
    return db.prepare(`DELETE FROM flights WHERE id = ?`).run(id);
}